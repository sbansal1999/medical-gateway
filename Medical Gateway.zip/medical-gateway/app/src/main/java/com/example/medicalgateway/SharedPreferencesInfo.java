package com.example.medicalgateway;

public class SharedPreferencesInfo {
    public final static String PREF_CURRENT_USER_INFO = "PREF_CURRENT_USER_INFO";
    public final static String PREF_IS_USER_SIGNED_IN = "PREF_IS_USER_SIGNED_IN";
}
